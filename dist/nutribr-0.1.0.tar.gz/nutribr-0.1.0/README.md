# nutribr

📊 **Biblioteca nutricional baseada na TACO/IBGE**  
Permite carregar, consultar e analisar alimentos com base na Tabela Brasileira de Composição de Alimentos. Agora com suporte a VDR, filtros avançados e interface CLI.

## 🔧 Funcionalidades

- ✅ Carregamento automático da TACO em `.csv`, `.json` ou `.xlsx`
- ✅ Representação orientada a objetos com a classe `Alimento`
- ✅ Cálculo automático de **Percentual do Valor Diário Recomendado (VDR%)**
- ✅ Filtros por categoria, calorias, proteínas, etc.
- ✅ Interface de linha de comando (CLI)

## 🚀 Instalação

```bash
pip install nutribr
```

Ou instale localmente:

```bash
git clone https://github.com/pedrorichil/nutribr.git
cd nutribr
pip install .
```

## 💡 Exemplo de uso (Python)

```python
from nutribr import TabelaNutricional

tabela = TabelaNutricional()
alimento = tabela.buscar_por_nome("Maçã")

print(alimento)
print(alimento.percentual_vdr())
```

## 🧪 Filtros avançados

```python
# Filtrar frutas com menos de 100 kcal
tabela.filtrar(categoria="Frutas", max_calorias=100)

# Filtrar alimentos ricos em proteína
tabela.filtrar(min_proteina=10)
```

## 🔍 Linha de Comando (CLI)

```bash
nutribr buscar "Arroz cozido"
nutribr listar --categoria "Frutas"
nutribr vdr "Peito de frango"
```

## 📁 Formatos suportados

- `.csv` (padrão)
- `.json`
- `.xls`, `.xlsx`

## 📚 Fonte dos dados

Os dados utilizados são baseados na TACO (Tabela Brasileira de Composição de Alimentos), disponibilizada pela **USP** e **IBGE**.

## 📦 Estrutura do Projeto

```
nutribr/
├── core.py         # Lógica principal (Alimento, TabelaNutricional)
├── cli.py          # Interface de linha de comando
├── data/
│   └── taco.csv    # Base nutricional de exemplo
└── __init__.py
```

## 👨‍💻 Autor

Pedro Richil – [@pedrorichil](https://github.com/pedrorichil)
